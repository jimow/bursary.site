<?php

return [
    'site_title' => 'Bursary',
];
