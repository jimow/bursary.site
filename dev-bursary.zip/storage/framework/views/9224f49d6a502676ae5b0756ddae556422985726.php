<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('application_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.applications.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.application.title_singular')); ?>

            </a>
            <button class="btn btn-warning" data-toggle="modal" data-target="#csvImportModal">
                <?php echo e(trans('global.app_csvImport')); ?>

            </button>
            <?php echo $__env->make('csvImport.modal', ['model' => 'Application', 'route' => 'admin.applications.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.application.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Application">
            <thead>
                <tr>
                    <th width="10">

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.id')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.user')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.user.fields.name')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.user.fields.email')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.first_name')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.last_name')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.other_names')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.location')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.sub_location')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.tel_no')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.village')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.institution')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.course')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.admission_number')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.form_year')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.disability')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.specify_disability')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.received_bursary_before')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.both_parents_alive')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.fathers_name')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.fathers_occupation')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.mothers_name')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.mothers_occupation')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.fathers_identity_card')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.mothers_identity_card')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.fathers_tel_no')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.mothers_tel_no')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.total_fees_payable')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.fee_balance')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.fees_structure')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.fee_balance_attach')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.student_grade')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.attach_student_grade')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.recommended')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.ward')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.on_scholarships')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.sub_county')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.voter_card')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.cdf_amount_awarded')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.county_amount_awarded')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.recommended_for_county')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.attach_voter_card')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.application.fields.gender')); ?>

                    </th>
                    <th>
                        &nbsp;
                    </th>
                </tr>
                <tr>
                    <td>
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <select class="search">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                    </td>
                    <td>
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <select class="search" strict="true">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = App\Models\Application::DISABILITY_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <select class="search" strict="true">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = App\Models\Application::RECEIVED_BURSARY_BEFORE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                        <select class="search" strict="true">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = App\Models\Application::BOTH_PARENTS_ALIVE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                    </td>
                    <td>
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                    </td>
                    <td>
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                    </td>
                    <td>
                        <select class="search" strict="true">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = App\Models\Application::RECOMMENDED_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                        <select class="search">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                        <select class="search" strict="true">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = App\Models\Application::ON_SCHOLARSHIPS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                        <select class="search">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = $sub_counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                    </td>
                    <td>
                        <select class="search" strict="true">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = App\Models\Application::RECOMMENDED_FOR_COUNTY_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                    </td>
                    <td>
                        <select class="search" strict="true">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <?php $__currentLoopData = App\Models\Application::GENDER_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                    </td>
                </tr>
            </thead>
        </table>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('application_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.applications.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
          return entry.id
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  let dtOverrideGlobals = {
    buttons: dtButtons,
    processing: true,
    serverSide: true,
    retrieve: true,
    aaSorting: [],
    ajax: "<?php echo e(route('admin.applications.index')); ?>",
    columns: [
      { data: 'placeholder', name: 'placeholder' },
{ data: 'id', name: 'id' },
{ data: 'user_name', name: 'user.name' },
{ data: 'user.name', name: 'user.name' },
{ data: 'user.email', name: 'user.email' },
{ data: 'first_name', name: 'first_name' },
{ data: 'last_name', name: 'last_name' },
{ data: 'other_names', name: 'other_names' },
{ data: 'location', name: 'location' },
{ data: 'sub_location', name: 'sub_location' },
{ data: 'tel_no', name: 'tel_no' },
{ data: 'village', name: 'village' },
{ data: 'institution', name: 'institution' },
{ data: 'course', name: 'course' },
{ data: 'admission_number', name: 'admission_number' },
{ data: 'form_year', name: 'form_year' },
{ data: 'disability', name: 'disability' },
{ data: 'specify_disability', name: 'specify_disability' },
{ data: 'received_bursary_before', name: 'received_bursary_before' },
{ data: 'both_parents_alive', name: 'both_parents_alive' },
{ data: 'fathers_name', name: 'fathers_name' },
{ data: 'fathers_occupation', name: 'fathers_occupation' },
{ data: 'mothers_name', name: 'mothers_name' },
{ data: 'mothers_occupation', name: 'mothers_occupation' },
{ data: 'fathers_identity_card', name: 'fathers_identity_card', sortable: false, searchable: false },
{ data: 'mothers_identity_card', name: 'mothers_identity_card', sortable: false, searchable: false },
{ data: 'fathers_tel_no', name: 'fathers_tel_no' },
{ data: 'mothers_tel_no', name: 'mothers_tel_no' },
{ data: 'total_fees_payable', name: 'total_fees_payable' },
{ data: 'fee_balance', name: 'fee_balance' },
{ data: 'fees_structure', name: 'fees_structure', sortable: false, searchable: false },
{ data: 'fee_balance_attach', name: 'fee_balance_attach', sortable: false, searchable: false },
{ data: 'student_grade', name: 'student_grade' },
{ data: 'attach_student_grade', name: 'attach_student_grade', sortable: false, searchable: false },
{ data: 'recommended', name: 'recommended' },
{ data: 'ward_name', name: 'ward.name' },
{ data: 'on_scholarships', name: 'on_scholarships' },
{ data: 'sub_county_name', name: 'sub_county.name' },
{ data: 'voter_card', name: 'voter_card' },
{ data: 'cdf_amount_awarded', name: 'cdf_amount_awarded' },
{ data: 'county_amount_awarded', name: 'county_amount_awarded' },
{ data: 'recommended_for_county', name: 'recommended_for_county' },
{ data: 'attach_voter_card', name: 'attach_voter_card', sortable: false, searchable: false },
{ data: 'gender', name: 'gender' },
{ data: 'actions', name: '<?php echo e(trans('global.actions')); ?>' }
    ],
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  };
  let table = $('.datatable-Application').DataTable(dtOverrideGlobals);
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
let visibleColumnsIndexes = null;
$('.datatable thead').on('input', '.search', function () {
      let strict = $(this).attr('strict') || false
      let value = strict && this.value ? "^" + this.value + "$" : this.value

      let index = $(this).parent().index()
      if (visibleColumnsIndexes !== null) {
        index = visibleColumnsIndexes[index]
      }

      table
        .column(index)
        .search(value, strict)
        .draw()
  });
table.on('column-visibility.dt', function(e, settings, column, state) {
      visibleColumnsIndexes = []
      table.columns(":visible").every(function(colIdx) {
          visibleColumnsIndexes.push(colIdx);
      });
  })
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ICTADMIN\Desktop\dev-bursary\resources\views/admin/applications/index.blade.php ENDPATH**/ ?>