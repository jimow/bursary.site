<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.application.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.applications.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="user_id"><?php echo e(trans('cruds.application.fields.user')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('user') ? 'is-invalid' : ''); ?>" name="user_id" id="user_id">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('user_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('user')): ?>
                    <span class="text-danger"><?php echo e($errors->first('user')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.user_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="first_name"><?php echo e(trans('cruds.application.fields.first_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>" type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', '')); ?>" required>
                <?php if($errors->has('first_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.first_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="last_name"><?php echo e(trans('cruds.application.fields.last_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name', '')); ?>" required>
                <?php if($errors->has('last_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.last_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="other_names"><?php echo e(trans('cruds.application.fields.other_names')); ?></label>
                <input class="form-control <?php echo e($errors->has('other_names') ? 'is-invalid' : ''); ?>" type="text" name="other_names" id="other_names" value="<?php echo e(old('other_names', '')); ?>">
                <?php if($errors->has('other_names')): ?>
                    <span class="text-danger"><?php echo e($errors->first('other_names')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.other_names_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="location"><?php echo e(trans('cruds.application.fields.location')); ?></label>
                <input class="form-control <?php echo e($errors->has('location') ? 'is-invalid' : ''); ?>" type="text" name="location" id="location" value="<?php echo e(old('location', '')); ?>">
                <?php if($errors->has('location')): ?>
                    <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.location_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="sub_location"><?php echo e(trans('cruds.application.fields.sub_location')); ?></label>
                <input class="form-control <?php echo e($errors->has('sub_location') ? 'is-invalid' : ''); ?>" type="text" name="sub_location" id="sub_location" value="<?php echo e(old('sub_location', '')); ?>">
                <?php if($errors->has('sub_location')): ?>
                    <span class="text-danger"><?php echo e($errors->first('sub_location')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.sub_location_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tel_no"><?php echo e(trans('cruds.application.fields.tel_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('tel_no') ? 'is-invalid' : ''); ?>" type="text" name="tel_no" id="tel_no" value="<?php echo e(old('tel_no', '')); ?>">
                <?php if($errors->has('tel_no')): ?>
                    <span class="text-danger"><?php echo e($errors->first('tel_no')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.tel_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="village"><?php echo e(trans('cruds.application.fields.village')); ?></label>
                <input class="form-control <?php echo e($errors->has('village') ? 'is-invalid' : ''); ?>" type="text" name="village" id="village" value="<?php echo e(old('village', '')); ?>">
                <?php if($errors->has('village')): ?>
                    <span class="text-danger"><?php echo e($errors->first('village')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.village_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="institution"><?php echo e(trans('cruds.application.fields.institution')); ?></label>
                <input class="form-control <?php echo e($errors->has('institution') ? 'is-invalid' : ''); ?>" type="text" name="institution" id="institution" value="<?php echo e(old('institution', '')); ?>" required>
                <?php if($errors->has('institution')): ?>
                    <span class="text-danger"><?php echo e($errors->first('institution')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.institution_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="course"><?php echo e(trans('cruds.application.fields.course')); ?></label>
                <input class="form-control <?php echo e($errors->has('course') ? 'is-invalid' : ''); ?>" type="text" name="course" id="course" value="<?php echo e(old('course', '')); ?>" required>
                <?php if($errors->has('course')): ?>
                    <span class="text-danger"><?php echo e($errors->first('course')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.course_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="admission_number"><?php echo e(trans('cruds.application.fields.admission_number')); ?></label>
                <input class="form-control <?php echo e($errors->has('admission_number') ? 'is-invalid' : ''); ?>" type="text" name="admission_number" id="admission_number" value="<?php echo e(old('admission_number', '')); ?>" required>
                <?php if($errors->has('admission_number')): ?>
                    <span class="text-danger"><?php echo e($errors->first('admission_number')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.admission_number_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="form_year"><?php echo e(trans('cruds.application.fields.form_year')); ?></label>
                <input class="form-control <?php echo e($errors->has('form_year') ? 'is-invalid' : ''); ?>" type="text" name="form_year" id="form_year" value="<?php echo e(old('form_year', '')); ?>" required>
                <?php if($errors->has('form_year')): ?>
                    <span class="text-danger"><?php echo e($errors->first('form_year')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.form_year_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.application.fields.disability')); ?></label>
                <?php $__currentLoopData = App\Models\Application::DISABILITY_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('disability') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="disability_<?php echo e($key); ?>" name="disability" value="<?php echo e($key); ?>" <?php echo e(old('disability', '') === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="disability_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('disability')): ?>
                    <span class="text-danger"><?php echo e($errors->first('disability')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.disability_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="specify_disability"><?php echo e(trans('cruds.application.fields.specify_disability')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('specify_disability') ? 'is-invalid' : ''); ?>" name="specify_disability" id="specify_disability" required><?php echo e(old('specify_disability')); ?></textarea>
                <?php if($errors->has('specify_disability')): ?>
                    <span class="text-danger"><?php echo e($errors->first('specify_disability')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.specify_disability_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.application.fields.received_bursary_before')); ?></label>
                <?php $__currentLoopData = App\Models\Application::RECEIVED_BURSARY_BEFORE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('received_bursary_before') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="received_bursary_before_<?php echo e($key); ?>" name="received_bursary_before" value="<?php echo e($key); ?>" <?php echo e(old('received_bursary_before', '') === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="received_bursary_before_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('received_bursary_before')): ?>
                    <span class="text-danger"><?php echo e($errors->first('received_bursary_before')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.received_bursary_before_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.application.fields.both_parents_alive')); ?></label>
                <?php $__currentLoopData = App\Models\Application::BOTH_PARENTS_ALIVE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('both_parents_alive') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="both_parents_alive_<?php echo e($key); ?>" name="both_parents_alive" value="<?php echo e($key); ?>" <?php echo e(old('both_parents_alive', '') === (string) $key ? 'checked' : ''); ?> required>
                        <label class="form-check-label" for="both_parents_alive_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('both_parents_alive')): ?>
                    <span class="text-danger"><?php echo e($errors->first('both_parents_alive')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.both_parents_alive_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="fathers_name"><?php echo e(trans('cruds.application.fields.fathers_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('fathers_name') ? 'is-invalid' : ''); ?>" type="text" name="fathers_name" id="fathers_name" value="<?php echo e(old('fathers_name', '')); ?>">
                <?php if($errors->has('fathers_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fathers_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.fathers_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="fathers_occupation"><?php echo e(trans('cruds.application.fields.fathers_occupation')); ?></label>
                <input class="form-control <?php echo e($errors->has('fathers_occupation') ? 'is-invalid' : ''); ?>" type="text" name="fathers_occupation" id="fathers_occupation" value="<?php echo e(old('fathers_occupation', '')); ?>">
                <?php if($errors->has('fathers_occupation')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fathers_occupation')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.fathers_occupation_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="mothers_name"><?php echo e(trans('cruds.application.fields.mothers_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('mothers_name') ? 'is-invalid' : ''); ?>" type="text" name="mothers_name" id="mothers_name" value="<?php echo e(old('mothers_name', '')); ?>">
                <?php if($errors->has('mothers_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('mothers_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.mothers_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="mothers_occupation"><?php echo e(trans('cruds.application.fields.mothers_occupation')); ?></label>
                <input class="form-control <?php echo e($errors->has('mothers_occupation') ? 'is-invalid' : ''); ?>" type="text" name="mothers_occupation" id="mothers_occupation" value="<?php echo e(old('mothers_occupation', '')); ?>">
                <?php if($errors->has('mothers_occupation')): ?>
                    <span class="text-danger"><?php echo e($errors->first('mothers_occupation')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.mothers_occupation_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="fathers_identity_card"><?php echo e(trans('cruds.application.fields.fathers_identity_card')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('fathers_identity_card') ? 'is-invalid' : ''); ?>" id="fathers_identity_card-dropzone">
                </div>
                <?php if($errors->has('fathers_identity_card')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fathers_identity_card')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.fathers_identity_card_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="mothers_identity_card"><?php echo e(trans('cruds.application.fields.mothers_identity_card')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('mothers_identity_card') ? 'is-invalid' : ''); ?>" id="mothers_identity_card-dropzone">
                </div>
                <?php if($errors->has('mothers_identity_card')): ?>
                    <span class="text-danger"><?php echo e($errors->first('mothers_identity_card')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.mothers_identity_card_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="fathers_tel_no"><?php echo e(trans('cruds.application.fields.fathers_tel_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('fathers_tel_no') ? 'is-invalid' : ''); ?>" type="text" name="fathers_tel_no" id="fathers_tel_no" value="<?php echo e(old('fathers_tel_no', '')); ?>">
                <?php if($errors->has('fathers_tel_no')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fathers_tel_no')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.fathers_tel_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="mothers_tel_no"><?php echo e(trans('cruds.application.fields.mothers_tel_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('mothers_tel_no') ? 'is-invalid' : ''); ?>" type="text" name="mothers_tel_no" id="mothers_tel_no" value="<?php echo e(old('mothers_tel_no', '')); ?>">
                <?php if($errors->has('mothers_tel_no')): ?>
                    <span class="text-danger"><?php echo e($errors->first('mothers_tel_no')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.mothers_tel_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="total_fees_payable"><?php echo e(trans('cruds.application.fields.total_fees_payable')); ?></label>
                <input class="form-control <?php echo e($errors->has('total_fees_payable') ? 'is-invalid' : ''); ?>" type="number" name="total_fees_payable" id="total_fees_payable" value="<?php echo e(old('total_fees_payable', '')); ?>" step="0.01" required>
                <?php if($errors->has('total_fees_payable')): ?>
                    <span class="text-danger"><?php echo e($errors->first('total_fees_payable')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.total_fees_payable_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="fee_balance"><?php echo e(trans('cruds.application.fields.fee_balance')); ?></label>
                <input class="form-control <?php echo e($errors->has('fee_balance') ? 'is-invalid' : ''); ?>" type="number" name="fee_balance" id="fee_balance" value="<?php echo e(old('fee_balance', '')); ?>" step="0.01" required>
                <?php if($errors->has('fee_balance')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fee_balance')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.fee_balance_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="fees_structure"><?php echo e(trans('cruds.application.fields.fees_structure')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('fees_structure') ? 'is-invalid' : ''); ?>" id="fees_structure-dropzone">
                </div>
                <?php if($errors->has('fees_structure')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fees_structure')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.fees_structure_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="fee_balance_attach"><?php echo e(trans('cruds.application.fields.fee_balance_attach')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('fee_balance_attach') ? 'is-invalid' : ''); ?>" id="fee_balance_attach-dropzone">
                </div>
                <?php if($errors->has('fee_balance_attach')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fee_balance_attach')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.fee_balance_attach_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="student_grade"><?php echo e(trans('cruds.application.fields.student_grade')); ?></label>
                <input class="form-control <?php echo e($errors->has('student_grade') ? 'is-invalid' : ''); ?>" type="text" name="student_grade" id="student_grade" value="<?php echo e(old('student_grade', '')); ?>" required>
                <?php if($errors->has('student_grade')): ?>
                    <span class="text-danger"><?php echo e($errors->first('student_grade')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.student_grade_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="attach_student_grade"><?php echo e(trans('cruds.application.fields.attach_student_grade')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('attach_student_grade') ? 'is-invalid' : ''); ?>" id="attach_student_grade-dropzone">
                </div>
                <?php if($errors->has('attach_student_grade')): ?>
                    <span class="text-danger"><?php echo e($errors->first('attach_student_grade')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.attach_student_grade_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="ward_id"><?php echo e(trans('cruds.application.fields.ward')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('ward') ? 'is-invalid' : ''); ?>" name="ward_id" id="ward_id">
                    <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('ward_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('ward')): ?>
                    <span class="text-danger"><?php echo e($errors->first('ward')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.ward_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.application.fields.on_scholarships')); ?></label>
                <select class="form-control <?php echo e($errors->has('on_scholarships') ? 'is-invalid' : ''); ?>" name="on_scholarships" id="on_scholarships">
                    <option value disabled <?php echo e(old('on_scholarships', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Application::ON_SCHOLARSHIPS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('on_scholarships', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('on_scholarships')): ?>
                    <span class="text-danger"><?php echo e($errors->first('on_scholarships')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.on_scholarships_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="voter_card"><?php echo e(trans('cruds.application.fields.voter_card')); ?></label>
                <input class="form-control <?php echo e($errors->has('voter_card') ? 'is-invalid' : ''); ?>" type="text" name="voter_card" id="voter_card" value="<?php echo e(old('voter_card', '')); ?>">
                <?php if($errors->has('voter_card')): ?>
                    <span class="text-danger"><?php echo e($errors->first('voter_card')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.voter_card_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="attach_voter_card"><?php echo e(trans('cruds.application.fields.attach_voter_card')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('attach_voter_card') ? 'is-invalid' : ''); ?>" id="attach_voter_card-dropzone">
                </div>
                <?php if($errors->has('attach_voter_card')): ?>
                    <span class="text-danger"><?php echo e($errors->first('attach_voter_card')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.attach_voter_card_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.application.fields.gender')); ?></label>
                <?php $__currentLoopData = App\Models\Application::GENDER_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('gender') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="gender_<?php echo e($key); ?>" name="gender" value="<?php echo e($key); ?>" <?php echo e(old('gender', '') === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="gender_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('gender')): ?>
                    <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.application.fields.gender_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.fathersIdentityCardDropzone = {
    url: '<?php echo e(route('admin.applications.storeMedia')); ?>',
    maxFilesize: 2, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2
    },
    success: function (file, response) {
      $('form').find('input[name="fathers_identity_card"]').remove()
      $('form').append('<input type="hidden" name="fathers_identity_card" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="fathers_identity_card"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($application) && $application->fathers_identity_card): ?>
      var file = <?php echo json_encode($application->fathers_identity_card); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="fathers_identity_card" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.mothersIdentityCardDropzone = {
    url: '<?php echo e(route('admin.applications.storeMedia')); ?>',
    maxFilesize: 2, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2
    },
    success: function (file, response) {
      $('form').find('input[name="mothers_identity_card"]').remove()
      $('form').append('<input type="hidden" name="mothers_identity_card" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="mothers_identity_card"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($application) && $application->mothers_identity_card): ?>
      var file = <?php echo json_encode($application->mothers_identity_card); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="mothers_identity_card" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.feesStructureDropzone = {
    url: '<?php echo e(route('admin.applications.storeMedia')); ?>',
    maxFilesize: 8, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 8
    },
    success: function (file, response) {
      $('form').find('input[name="fees_structure"]').remove()
      $('form').append('<input type="hidden" name="fees_structure" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="fees_structure"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($application) && $application->fees_structure): ?>
      var file = <?php echo json_encode($application->fees_structure); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="fees_structure" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.feeBalanceAttachDropzone = {
    url: '<?php echo e(route('admin.applications.storeMedia')); ?>',
    maxFilesize: 2, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2
    },
    success: function (file, response) {
      $('form').find('input[name="fee_balance_attach"]').remove()
      $('form').append('<input type="hidden" name="fee_balance_attach" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="fee_balance_attach"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($application) && $application->fee_balance_attach): ?>
      var file = <?php echo json_encode($application->fee_balance_attach); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="fee_balance_attach" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.attachStudentGradeDropzone = {
    url: '<?php echo e(route('admin.applications.storeMedia')); ?>',
    maxFilesize: 8, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 8
    },
    success: function (file, response) {
      $('form').find('input[name="attach_student_grade"]').remove()
      $('form').append('<input type="hidden" name="attach_student_grade" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="attach_student_grade"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($application) && $application->attach_student_grade): ?>
      var file = <?php echo json_encode($application->attach_student_grade); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="attach_student_grade" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.attachVoterCardDropzone = {
    url: '<?php echo e(route('admin.applications.storeMedia')); ?>',
    maxFilesize: 2, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2
    },
    success: function (file, response) {
      $('form').find('input[name="attach_voter_card"]').remove()
      $('form').append('<input type="hidden" name="attach_voter_card" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="attach_voter_card"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($application) && $application->attach_voter_card): ?>
      var file = <?php echo json_encode($application->attach_voter_card); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="attach_voter_card" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ICTADMIN\Desktop\dev-bursary\resources\views/admin/applications/create.blade.php ENDPATH**/ ?>