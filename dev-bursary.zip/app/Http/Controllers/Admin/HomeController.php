<?php

namespace App\Http\Controllers\Admin;

use LaravelDaily\LaravelCharts\Classes\LaravelChart;

class HomeController
{
    public function index()
    {
        $settings1 = [
            'chart_title'        => 'Applications By Ward',
            'chart_type'         => 'bar',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'count',
            'filter_field'       => 'created_at',
            'filter_days'        => '90',
            'column_class'       => 'col-md-12',
            'entries_number'     => '5',
            'relationship_name'  => 'ward',
            'translation_key'    => 'application',
        ];

        $chart1 = new LaravelChart($settings1);

        $settings2 = [
            'chart_title'        => 'Pie Chart - Applications by Ward',
            'chart_type'         => 'pie',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'count',
            'filter_field'       => 'created_at',
            'filter_days'        => '90',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'ward',
            'translation_key'    => 'application',
        ];

        $chart2 = new LaravelChart($settings2);

        $settings3 = [
            'chart_title'        => 'Applicants Fees Payable Per Ward',
            'chart_type'         => 'pie',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'total_fees_payable',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'ward',
            'translation_key'    => 'application',
        ];

        $chart3 = new LaravelChart($settings3);

        $settings4 = [
            'chart_title'        => 'Application Fee Balance Per Ward',
            'chart_type'         => 'pie',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'fee_balance',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'ward',
            'translation_key'    => 'application',
        ];

        $chart4 = new LaravelChart($settings4);

        $settings5 = [
            'chart_title'        => 'Application Fee Balance Per Sub County',
            'chart_type'         => 'line',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'fee_balance',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-12',
            'entries_number'     => '5',
            'relationship_name'  => 'sub_county',
            'translation_key'    => 'application',
        ];

        $chart5 = new LaravelChart($settings5);

        $settings6 = [
            'chart_title'        => 'Applicants Fee Balance Per Sub County',
            'chart_type'         => 'line',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'fee_balance',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'sub_county',
            'translation_key'    => 'application',
        ];

        $chart6 = new LaravelChart($settings6);

        $settings7 = [
            'chart_title'        => 'Applicants Total Fees Payable Per Ward',
            'chart_type'         => 'line',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'total_fees_payable',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'ward',
            'translation_key'    => 'application',
        ];

        $chart7 = new LaravelChart($settings7);

        $settings8 = [
            'chart_title'        => 'Applicants Total Fees Payable Per Sub County',
            'chart_type'         => 'line',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'total_fees_payable',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'sub_county',
            'translation_key'    => 'application',
        ];

        $chart8 = new LaravelChart($settings8);

        $settings9 = [
            'chart_title'        => 'Applicants Total Fees Payable Per Ward',
            'chart_type'         => 'pie',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'total_fees_payable',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'ward',
            'translation_key'    => 'application',
        ];

        $chart9 = new LaravelChart($settings9);

        $settings10 = [
            'chart_title'        => 'Applicants Total Fees Payable Per Sub County',
            'chart_type'         => 'pie',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'total_fees_payable',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'sub_county',
            'translation_key'    => 'application',
        ];

        $chart10 = new LaravelChart($settings10);

        $settings11 = [
            'chart_title'        => 'Applicants Total Fees Balance Per Ward',
            'chart_type'         => 'pie',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'sum',
            'aggregate_field'    => 'fee_balance',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'ward',
            'translation_key'    => 'application',
        ];

        $chart11 = new LaravelChart($settings11);

        $settings12 = [
            'chart_title'        => 'Applicants Total Fees Payable Per Sub County',
            'chart_type'         => 'line',
            'report_type'        => 'group_by_relationship',
            'model'              => 'App\Models\Application',
            'group_by_field'     => 'name',
            'aggregate_function' => 'avg',
            'aggregate_field'    => 'total_fees_payable',
            'filter_field'       => 'created_at',
            'column_class'       => 'col-md-4',
            'entries_number'     => '5',
            'relationship_name'  => 'sub_county',
            'translation_key'    => 'application',
        ];

        $chart12 = new LaravelChart($settings12);

        return view('home', compact('chart1', 'chart10', 'chart11', 'chart12', 'chart2', 'chart3', 'chart4', 'chart5', 'chart6', 'chart7', 'chart8', 'chart9'));
    }
}
