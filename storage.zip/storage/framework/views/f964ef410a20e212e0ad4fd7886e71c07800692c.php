<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.ward.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.wards.update", [$ward->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.ward.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $ward->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ward.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="sub_county_id"><?php echo e(trans('cruds.ward.fields.sub_county')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('sub_county') ? 'is-invalid' : ''); ?>" name="sub_county_id" id="sub_county_id">
                    <?php $__currentLoopData = $sub_counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('sub_county_id') ? old('sub_county_id') : $ward->sub_county->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('sub_county')): ?>
                    <span class="text-danger"><?php echo e($errors->first('sub_county')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ward.fields.sub_county_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ICTADMIN\Downloads\dev-bursary\resources\views/admin/wards/edit.blade.php ENDPATH**/ ?>