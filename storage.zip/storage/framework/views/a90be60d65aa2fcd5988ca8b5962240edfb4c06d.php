<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <span class="brand-text font-weight-light"><?php echo e(trans('panel.site_title')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li>
                    <select class="searchable-field form-control">

                    </select>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs("admin.home") ? "active" : ""); ?>" href="<?php echo e(route("admin.home")); ?>">
                        <i class="fas fa-fw fa-tachometer-alt nav-icon">
                        </i>
                        <p>
                            <?php echo e(trans('global.dashboard')); ?>

                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/permissions*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/users*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/permissions*") ? "active" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "active" : ""); ?> <?php echo e(request()->is("admin/users*") ? "active" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "active" : ""); ?>" href="#">
                            <i class="fa-fw nav-icon fas fa-users">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.permission.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.role.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.user.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('audit_log_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-file-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.auditLog.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/counties*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/sub-counties*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/wards*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/system-settings*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/courses*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/counties*") ? "active" : ""); ?> <?php echo e(request()->is("admin/sub-counties*") ? "active" : ""); ?> <?php echo e(request()->is("admin/wards*") ? "active" : ""); ?> <?php echo e(request()->is("admin/system-settings*") ? "active" : ""); ?> <?php echo e(request()->is("admin/courses*") ? "active" : ""); ?>" href="#">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.setting.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('county_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.counties.index")); ?>" class="nav-link <?php echo e(request()->is("admin/counties") || request()->is("admin/counties/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-closed-captioning">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.county.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sub_county_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.sub-counties.index")); ?>" class="nav-link <?php echo e(request()->is("admin/sub-counties") || request()->is("admin/sub-counties/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-angle-right">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.subCounty.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ward_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.wards.index")); ?>" class="nav-link <?php echo e(request()->is("admin/wards") || request()->is("admin/wards/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-cogs">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.ward.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('system_setting_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.system-settings.index")); ?>" class="nav-link <?php echo e(request()->is("admin/system-settings") || request()->is("admin/system-settings/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-cogs">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.systemSetting.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('course_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.courses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/courses") || request()->is("admin/courses/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-cogs">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.course.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-bell">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userAlert.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('application_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.applications.index")); ?>" class="nav-link <?php echo e(request()->is("admin/applications") || request()->is("admin/applications/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.application.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('institution_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.institutions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/institutions") || request()->is("admin/institutions/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.institution.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('financial_year_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.financial-years.index")); ?>" class="nav-link <?php echo e(request()->is("admin/financial-years") || request()->is("admin/financial-years/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fab fa-affiliatetheme">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.financialYear.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/content-categories*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/content-tags*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/content-pages*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/content-categories*") ? "active" : ""); ?> <?php echo e(request()->is("admin/content-tags*") ? "active" : ""); ?> <?php echo e(request()->is("admin/content-pages*") ? "active" : ""); ?>" href="#">
                            <i class="fa-fw nav-icon fas fa-book">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.contentManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_category_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.content-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/content-categories") || request()->is("admin/content-categories/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-folder">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.contentCategory.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_tag_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.content-tags.index")); ?>" class="nav-link <?php echo e(request()->is("admin/content-tags") || request()->is("admin/content-tags/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-tags">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.contentTag.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_page_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.content-pages.index")); ?>" class="nav-link <?php echo e(request()->is("admin/content-pages") || request()->is("admin/content-pages/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-file">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.contentPage.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('award_upload_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.award-uploads.index")); ?>" class="nav-link <?php echo e(request()->is("admin/award-uploads") || request()->is("admin/award-uploads/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.awardUpload.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "active" : ""); ?> nav-link">
                            <i class="fa-fw fa fa-envelope nav-icon">

                            </i>
                            <p><?php echo e(trans('global.messages')); ?></p>
                            <?php if($unread > 0): ?>
                                <strong>( <?php echo e($unread); ?> )</strong>
                            <?php endif; ?>

                        </a>
                    </li>
                    <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                                    <i class="fa-fw fas fa-key nav-icon">
                                    </i>
                                    <p>
                                        <?php echo e(trans('global.change_password')); ?>

                                    </p>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                            <p>
                                <i class="fas fa-fw fa-sign-out-alt nav-icon">

                                </i>
                                <p><?php echo e(trans('global.logout')); ?></p>
                            </p>
                        </a>
                    </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\Users\ICTADMIN\Downloads\dev-bursary\resources\views/partials/menu.blade.php ENDPATH**/ ?>