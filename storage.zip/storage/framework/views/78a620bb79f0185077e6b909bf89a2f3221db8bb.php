<?php echo e($slot); ?>

<?php /**PATH C:\Users\ICTADMIN\Downloads\dev-bursary\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>