<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.systemSetting.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.system-settings.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="financial_year_id"><?php echo e(trans('cruds.systemSetting.fields.financial_year')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('financial_year') ? 'is-invalid' : ''); ?>" name="financial_year_id" id="financial_year_id">
                    <?php $__currentLoopData = $financial_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('financial_year_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('financial_year')): ?>
                    <span class="text-danger"><?php echo e($errors->first('financial_year')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.systemSetting.fields.financial_year_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.systemSetting.fields.system_status')); ?></label>
                <?php $__currentLoopData = App\Models\SystemSetting::SYSTEM_STATUS_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('system_status') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="system_status_<?php echo e($key); ?>" name="system_status" value="<?php echo e($key); ?>" <?php echo e(old('system_status', '') === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="system_status_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('system_status')): ?>
                    <span class="text-danger"><?php echo e($errors->first('system_status')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.systemSetting.fields.system_status_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ICTADMIN\Downloads\dev-bursary\resources\views/admin/systemSettings/create.blade.php ENDPATH**/ ?>