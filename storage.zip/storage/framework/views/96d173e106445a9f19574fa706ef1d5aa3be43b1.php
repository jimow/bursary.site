
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    Ward Manager's Dashboard - <?php echo e($ward_name); ?>

</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
<!-- Application per course -->
<div class="row">
    <div class="col-md-6">
    
    <table class="table">
    
    <tr class="bg-success">
    <th colspan="2"> <h3>Application As Per Courses</h3></th>
    </tr>
    
    <?php $__currentLoopData = $application_per_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap_c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    
    
    <tr>
    <td class="bg-info"><?php echo e($ap_c->course->name); ?></td>
    <td class="bg-primary text-right"><?php echo e(number_format($ap_c->total_course)); ?></td>
    <?php
    
  
    $count_app_c += $ap_c->total_course;
    ?>
    
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
    
    <td class="bg-success text-right"><h4> Total Amount Awarded</h4></td>
    <td class="bg-success text-right"><h4><?php echo e($count_app_c); ?></h4></td>
    </tr>
    
    
    
    </table>
    
    
    </div>
    <div class="col-md-6" >
    <canvas id="course_app" style="width:500;max-width:500px"></canvas>
    
    
    </div>
    </div>
    <?php $__currentLoopData = $amount_awarded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $am): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($am->sum); ?>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ICTADMIN\Downloads\dev-bursary\resources\views/countydashboard.blade.php ENDPATH**/ ?>