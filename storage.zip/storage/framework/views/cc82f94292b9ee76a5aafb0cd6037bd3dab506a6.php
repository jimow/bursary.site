
<?php $__env->startSection('content'); ?>


<?php echo e($name); ?>

<?php echo e($amount_awarded); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ICTADMIN\Downloads\dev-bursary\resources\views/home2.blade.php ENDPATH**/ ?>